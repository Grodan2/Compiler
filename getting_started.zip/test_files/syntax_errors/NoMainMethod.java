public class NoMainMethod {
    public void display() { // @error - syntax (No main method, which is required by the grammar)
        System.out.println("Hello");
    }
}
