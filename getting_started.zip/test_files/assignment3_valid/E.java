public class E {
  public static void main(String[] a) {
    {
      System.out.println((4 * 2) + 10 - 2 * 6 + (4 - 1) * 2 * 2);
      System.out.println(true == (!true && false) || 10 > 1 && 1 < 10);
    }
  }
}
